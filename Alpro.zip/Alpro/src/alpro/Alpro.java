
package alpro;


public class Alpro {

    public static void main(String args[]) {
        Editor e = new Editor();
        e.main();
//        Play e = new Play();
//        e.main();
    }
    
}
